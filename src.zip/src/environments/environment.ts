export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:4000' // ← change this to your dev API
};
