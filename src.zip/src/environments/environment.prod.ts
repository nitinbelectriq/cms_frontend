// export const environment = {
//   production: true,
//   apiBaseUrl: 'https://api.yourdomain.com/api' // ← change this to your prod API
// };
