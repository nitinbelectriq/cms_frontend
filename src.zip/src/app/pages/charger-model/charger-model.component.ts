import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-charger-model',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatIconModule, MatButtonModule],
  templateUrl: './charger-model.component.html',
  styleUrls: ['./charger-model.component.scss']
})
export class ChargerModelComponent {
  displayedColumns: string[] = ['model', 'description', 'status', 'action'];
  dataSource = [
    { model: 'TEST', description: 'TEST1', status: 'Active' },
    { model: 'Bulk Charger', description: '8 Channel', status: 'Active' },
    { model: 'HMC TESTING', description: 'For testing', status: 'Active' },
    { model: 'Harmonu/DualGun', description: 'Harmonu/DualGun charger for connector 0 1 2', status: 'Active' },
    { model: 'RModel', description: 'ods', status: 'Active' },
    { model: 'HMC Low voltage Charger', description: '13kw', status: 'Active' },
    { model: 'Swapping Station', description: '28Channel', status: 'Active' },
    { model: '80kW', description: '3gun', status: 'Active' }
  ];
}
