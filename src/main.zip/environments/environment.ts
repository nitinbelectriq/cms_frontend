export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:5500' // ← change this to your dev API
};
