import { Component } from '@angular/core';

@Component({
  selector: 'app-create-manage-charger',
  standalone: true,
  imports: [],
  templateUrl: './create-manage-charger.component.html',
  styleUrl: './create-manage-charger.component.scss'
})
export class CreateManageChargerComponent {

}
