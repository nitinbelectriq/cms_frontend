import { Component } from '@angular/core';

@Component({
  selector: 'app-view-manage-charger',
  standalone: true,
  imports: [],
  templateUrl: './view-manage-charger.component.html',
  styleUrl: './view-manage-charger.component.scss'
})
export class ViewManageChargerComponent {

}
