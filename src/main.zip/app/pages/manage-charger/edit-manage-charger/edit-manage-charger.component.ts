import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-manage-charger',
  standalone: true,
  imports: [],
  templateUrl: './edit-manage-charger.component.html',
  styleUrl: './edit-manage-charger.component.scss'
})
export class EditManageChargerComponent {

}
