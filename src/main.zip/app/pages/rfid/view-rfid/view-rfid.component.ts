import { Component } from '@angular/core';

@Component({
  selector: 'app-view-rfid',
  standalone: true,
  imports: [],
  templateUrl: './view-rfid.component.html',
  styleUrl: './view-rfid.component.scss'
})
export class ViewRfidComponent {

}
