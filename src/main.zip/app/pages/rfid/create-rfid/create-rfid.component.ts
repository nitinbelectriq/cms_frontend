import { Component } from '@angular/core';

@Component({
  selector: 'app-create-rfid',
  standalone: true,
  imports: [],
  templateUrl: './create-rfid.component.html',
  styleUrl: './create-rfid.component.scss'
})
export class CreateRfidComponent {

}
