import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-rfid',
  standalone: true,
  imports: [],
  templateUrl: './edit-rfid.component.html',
  styleUrl: './edit-rfid.component.scss'
})
export class EditRfidComponent {

}
