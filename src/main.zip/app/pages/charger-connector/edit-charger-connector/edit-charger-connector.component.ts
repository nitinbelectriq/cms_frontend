import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-charger-connector',
  standalone: true,
  imports: [],
  templateUrl: './edit-charger-connector.component.html',
  styleUrl: './edit-charger-connector.component.scss'
})
export class EditChargerConnectorComponent {

}
