import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-charger-variant',
  standalone: true,
  imports: [],
  templateUrl: './edit-charger-variant.component.html',
  styleUrl: './edit-charger-variant.component.scss'
})
export class EditChargerVariantComponent {

}
