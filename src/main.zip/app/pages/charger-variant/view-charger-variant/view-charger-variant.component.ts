import { Component } from '@angular/core';

@Component({
  selector: 'app-view-charger-variant',
  standalone: true,
  imports: [],
  templateUrl: './view-charger-variant.component.html',
  styleUrl: './view-charger-variant.component.scss'
})
export class ViewChargerVariantComponent {

}
