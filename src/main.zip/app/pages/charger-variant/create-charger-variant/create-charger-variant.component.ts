import { Component } from '@angular/core';

@Component({
  selector: 'app-create-charger-variant',
  standalone: true,
  imports: [],
  templateUrl: './create-charger-variant.component.html',
  styleUrl: './create-charger-variant.component.scss'
})
export class CreateChargerVariantComponent {

}
